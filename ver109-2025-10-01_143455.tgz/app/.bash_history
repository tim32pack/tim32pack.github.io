npm init
cd src
npm init
node index.js
node index.js
npm install socket.io
npm install express socket.io
